import org.graphstream.graph.Graph;
import org.graphstream.graph.Node;
import org.graphstream.graph.Edge;
import org.graphstream.graph.implementations.SingleGraph;

import java.util.HashSet;
import java.util.Set;

public class DFSRoutingSimulation {
    private Graph graph;
    private Set<String> visited;

    public DFSRoutingSimulation() {
        // Use Swing viewer instead of JavaFX
        System.setProperty("org.graphstream.ui", "swing");

        graph = new SingleGraph("DFS Spanning Tree");
        visited = new HashSet<>();
    }

    public void addNode(String nodeId, int x, int y) {
        if (graph.getNode(nodeId) == null) {
            Node node = graph.addNode(nodeId);
            node.addAttribute("ui.label", nodeId);
            node.setAttribute("xy", x, y);  // 👈 Position the node manually
        }
    }


    public void addEdge(String edgeId, String node1, String node2) {
        if (graph.getEdge(edgeId) == null && graph.getNode(node1) != null && graph.getNode(node2) != null) {
            // false = undirected edge (important for full traversal)
            Edge edge = graph.addEdge(edgeId, node1, node2, false);
            edge.addAttribute("ui.label", edgeId);
        }
    }

    public void dfs(String current) {
        visited.add(current);
        Node currentNode = graph.getNode(current);
        currentNode.addAttribute("ui.class", "visited"); // ✅ fixed

        for (Edge edge : currentNode.getEachEdge()) {
            Node neighbor = edge.getOpposite(currentNode);
            if (!visited.contains(neighbor.getId())) {
                edge.addAttribute("ui.class", "treeEdge"); // ✅ fixed
                dfs(neighbor.getId());
            }
        }
    }


    public void showGraph() {
        graph.setAttribute("ui.stylesheet", styleSheet);
        graph.setAttribute("ui.quality");
        graph.setAttribute("ui.antialias");

        // Disable layout engine (avoids NoClassDefFoundError)
        graph.display(false);  // use "false" to skip layout engine
    }

    protected String styleSheet =
            "node {" +
                    "   fill-color: gray;" +
                    "   size: 25px;" +
                    "   text-size: 20;" +
                    "}" +
                    "node.visited {" +
                    "   fill-color: green;" +
                    "}" +
                    "edge.treeEdge {" +
                    "   fill-color: red;" +
                    "   size: 3px;" +
                    "}";

    public static void main(String[] args) {
        DFSRoutingSimulation sim = new DFSRoutingSimulation();

        // Add nodes with manual positions
        sim.addNode("A", 0, 0);
        sim.addNode("B", 1, 1);
        sim.addNode("C", 1, -1);
        sim.addNode("D", 2, 2);
        sim.addNode("E", 2, -2);

        // Add edges (undirected)
        sim.addEdge("AB", "A", "B");
        sim.addEdge("AC", "A", "C");
        sim.addEdge("BD", "B", "D");
        sim.addEdge("CE", "C", "E");

        // Perform DFS starting from A
        sim.dfs("A");

        // Display the graph
        sim.showGraph();
    }

    }

